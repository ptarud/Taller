#include <list>
#include <vector>
#include <set>
#include <queue>
#include <iostream> 
#include <sstream>
#include <string.h>
#include <algorithm>

#include <stdlib.h>
#include <fstream>
#include <math.h>
#include <sys/time.h>
#include <sys/types.h>
#include <signal.h>

using namespace std;

#define MAX_ITER 10
#define M 6
#define N 3
#define H 2



