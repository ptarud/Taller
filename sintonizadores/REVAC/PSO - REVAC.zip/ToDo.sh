./REVAC ejecutable_algoritmo.sh configuracion.config instancias/N25-1.nsp 1
