./paramils -numRun 4 -maxEvals 100 -maxIts 100 -approach focused -N 1000 -userunlog 1 -validN 50 -pruning 0 -scenariofile scenario-instancia.scn > ParamILS-instancia.out 

