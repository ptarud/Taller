nohup ./REVAC ejecutable_algoritmo.sh configuracion.config instancias 1 > Salida-Revac.out &
